<?php
/**
 * Hello controller.
 */

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class HelloController.
 */
 #[Route('/404')]
class ErrorController extends AbstractController
{
    #[Route('/404')]
    public function index(string $name): Response
    {
        return $this->render(
            '404.html.twig',
        );
    }
}