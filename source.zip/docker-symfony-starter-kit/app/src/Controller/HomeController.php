<?php

namespace App\Controller;


use App\Entity\Product;
use App\Service\HomeService;
use App\Service\HomeServiceInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    private HomeServiceInterface $homeService;

    public function __construct(HomeServiceInterface $homeService)
    {
        $this->homeService = $homeService;
    }
    #[Route(
        '/',
        name: 'home',
        methods: 'GET'
    )]
    public function index(Request $request): Response
    {
        $pagination = $this->homeService->getPaginatedList(
            $request->query->getInt('page', 1)
        );
        return $this->render('home/index.html.twig', ['pagination' => $pagination]);
    }
}
