<?php
/**
 * Task service.
 */

namespace App\Service;

use App\Entity\Category;
use App\Repository\ProductRepository;
use Knp\Component\Pager\Pagination\PaginationInterface;
use Knp\Component\Pager\PaginatorInterface;

/**
 * Class TaskService.
 */
class HomeService implements HomeServiceInterface
{
    private ProductRepository $productRepository;

    private PaginatorInterface $paginator;

    public function __construct(ProductRepository $productRepository, PaginatorInterface $paginator)
    {
        $this->productRepository = $productRepository;
        $this->paginator = $paginator;
    }

    /**
     * Get paginated list.
     *
     * @param int $page Page number
     *
     * @return PaginationInterface<string, mixed> Paginated list
     */
    public function getPaginatedList(int $page): PaginationInterface
    {
        return $this->paginator->paginate(
            $this->productRepository->queryAll(),
            $page,
            ProductRepository::PAGINATOR_ITEMS_PER_PAGE
        );
    }

    
}