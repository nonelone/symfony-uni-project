<?php

namespace App\DataFixtures;

use App\Entity\Product;
use DateTimeImmutable;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;
use Faker\Generator;

class ProductFixtures extends Fixture
{

    protected Generator $faker;
    protected ObjectManager $manager;
    public function load(ObjectManager $manager): void
    {

        $this->faker = Factory::create();

        for ($i = 0; $i < 100; ++$i) {
            $product = new Product();
            $product->setProductName($this->faker->word);
            $product->setPublished(
                DateTimeImmutable::createFromMutable($this->faker->dateTimeBetween('-100 days', '-1 days'))
            );
            $product->setProductID($i);
            $product->setCoverImage($this->faker->word);
            $product->setScore(1);
            $product->setProductDescription("");
            $manager->persist($product);
        }

        $manager->flush();
    }
}
